import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._  // for implicit conversations
import org.apache.spark.sql._

//Question 1

val sc = new SparkContext("local","SparkSQL Example")
val input = sc.parallelize(List(1,3,3))
input.foreach(println)

val fileC = input.keyBy(x=>x).mapValues(x=>x+1)
fileC.foreach(println)


//Question 2

val input2 = sc.parallelize(List("a","b","c","d","e"))
input2.foreach(println)

val input = List("a","b","c","d","e")

val fileC = input2.keyBy(x=>x).mapValues(x=>input.indexOf(x))
fileC.foreach(println)